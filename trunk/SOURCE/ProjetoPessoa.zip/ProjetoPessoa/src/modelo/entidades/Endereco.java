package modelo.entidades;

public class Endereco {
 
	private int numero;
	 
	private String complemento;
	 
	private String logradouro;
	 
	private String bairro;
	 
	private int tipoLogradouro;
	 
	private int CEP;
	 
	private Municipio municipio;
	 
	private _Pessoa[] pessoa;
	 
}
 
