package modelo.entidades;

public class Municipio {
 
	private String nome;
	 
	private UF uF;
	 
	private Endereco[] endereco;
	 
}
 
