package modelo.entidades;

public class UF {
 
	private String sigla;
	 
	private String nome;
	 
	private Municipio[] municipio;
	 
}
 
