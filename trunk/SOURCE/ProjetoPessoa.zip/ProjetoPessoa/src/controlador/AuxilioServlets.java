package controlador;

public class AuxilioServlets {
	
	public static boolean naoEhNuloOuVazio(String param){
		return !(param == null || param == "");
	}

}
