package excecoes;

public class PadraoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PadraoException(String mensagem){
		super(mensagem);
	}
}
