package form;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

import core.UIController;

public class MenuPrincipal extends List implements CommandListener {

	private static MenuPrincipal instance;
	
	private Command cmd_sair;
	//private Command cmd_voltar;
	private Command cmd_ok;
	private Command cmd_ok1;
	private Command cmd_ok2;
	private Command cmd_ok3;

	private MenuPrincipal(String title) {
		super(title, IMPLICIT);

//		append("Unidade de Saude", null);
//		append("Profissional de Saude", null);
		append("Paciente", null);
		append("Atendimento", null);
		append("Atendimento", null);
		append("Atendimento", null);
		append("Atendimento", null);
		

		cmd_sair = new Command("sair", Command.EXIT, 0);
		//cmd_voltar = new Command("voltar", Command.BACK, 1);
		cmd_ok = new Command("Ok", Command.OK, 2);
		cmd_ok1 = new Command("Cadastrar", Command.OK, 2);
		cmd_ok2 = new Command("Atualizar", Command.OK, 2);
		cmd_ok3 = new Command("Listar", Command.OK, 2);

		addCommand(cmd_sair);
//		addCommand(cmd_voltar);
		addCommand(cmd_ok);
		addCommand(cmd_ok1);
		addCommand(cmd_ok2);
		addCommand(cmd_ok3);

		setCommandListener(this);
	}

	public static MenuPrincipal getInstance(String title) {
		if (instance == null) {
			instance = new MenuPrincipal(title);
		}
		return instance;
	}

	public void commandAction(Command cmd, Displayable arg1) {
		if (cmd.equals(cmd_sair)) {
			UIController.getInstance().sair();
		} else if (cmd.equals(cmd_ok)) {
			UIController.getInstance().ok(getSelectedIndex());
		}
	}
}
