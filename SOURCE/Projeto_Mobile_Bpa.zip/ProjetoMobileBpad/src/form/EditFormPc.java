package form;

import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;

public class EditFormPc extends Form {
	private Paciente paciente;
	private TextField pcCnsFld = new TextField("CNS: ", "", 6, TextField.ANY);
	private TextField pcNomeFld = new TextField("Paciente: ", "", 20,
			TextField.ANY);
	private TextField pcDtNascFld = new TextField("Data Nasc.: ", "", 10,
			TextField.ANY);
	private TextField pcSexoFld = new TextField("Sexo:", "", 1, TextField.ANY);
	private TextField pcEnderecoFld = new TextField("Endereco: ", "", 20,
			TextField.ANY);

	public EditFormPc() {
		super("Editar Paciente");
		append(pcCnsFld);
		append(pcNomeFld);
		append(pcDtNascFld);
		append(pcSexoFld);
		append(pcEnderecoFld);

	}

	public void setPaciente(Paciente c)// envia para a classe conta
	{
		paciente = c;
		pcCnsFld.setString(paciente.pcCns);
		pcNomeFld.setString(paciente.pcNome);
		pcDtNascFld.setString(paciente.pcDtNasc);
		pcSexoFld.setString(paciente.pcSexo);
		pcEnderecoFld.setString(paciente.pcEndereco);
	}

	public Paciente getPaciente()// atribui para a classe conta
	{
		paciente.pcCns = pcCnsFld.getString();
		paciente.pcNome = pcNomeFld.getString();
		paciente.pcDtNasc = pcDtNascFld.getString();
		paciente.pcSexo = pcSexoFld.getString();
		paciente.pcEndereco = pcEnderecoFld.getString();
		return paciente;
	}
}
