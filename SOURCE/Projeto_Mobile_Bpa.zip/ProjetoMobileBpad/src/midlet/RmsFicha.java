package midlet;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;

import record.NameComparatorFd;
import record.NameFilterFd;
import core.UIController;
import form.EditFormFd;
import form.Ficha;
import form.SearchFormFd;

public class RmsFicha extends Form implements CommandListener {
	private Command addCmd;
	private Command selectCmd;
	private Command exitCmd;

	private Command saveCmd ;
	private Command deleteCmd;
	private Command cancelCmd;

	private Command searchCmd;

	private List listaFd;
	private EditFormFd formFd;
	private SearchFormFd searchFormFd ;

	private NameComparatorFd orderby ;
	private NameFilterFd nameFilter;

	private Ficha[] currentFichaList;

	private static RmsFicha instance;

	public static RmsFicha getInstance(String title) {
		if (instance == null) {
			instance = new RmsFicha(title);
		}
		return instance;
	}

	
	private RmsFicha(String title) {
		super(title);
		addCmd = new Command("Nova Ficha", Command.SCREEN, 1);
		selectCmd = new Command("Visualizar", Command.ITEM, 1);
		exitCmd = new Command("Sair", Command.EXIT, 1);

		saveCmd = new Command("Salvar", Command.SCREEN, 1);
		deleteCmd = new Command("Remover", Command.SCREEN, 1);
		cancelCmd = new Command("Cancelar", Command.SCREEN, 1);

		searchCmd = new Command("Buscar", Command.SCREEN, 1);

		listaFd = new List("Fichas", List.IMPLICIT);
		formFd = new EditFormFd();
		searchFormFd = new SearchFormFd();

		orderby = new NameComparatorFd();
		nameFilter = new NameFilterFd(orderby);

		formFd.addCommand(saveCmd);
		formFd.addCommand(cancelCmd);
		formFd.addCommand(deleteCmd);
		formFd.setCommandListener(this);

		searchFormFd.addCommand(searchCmd);
		searchFormFd.setCommandListener(this);

		listaFd.addCommand(searchCmd);
		listaFd.addCommand(addCmd);
		listaFd.addCommand(exitCmd);
		listaFd.setSelectCommand(selectCmd);
		listaFd.setCommandListener(this);

	}

	public void startApp() {
//		refreshList();
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unc) {
	}

//	private void refreshList() {
//		listaFd.deleteAll();
//		currentFichaList = Ficha.listaFd(orderby, nameFilter);
//		for (int ccnt = 0; ccnt < currentFichaList.length; ccnt++) {
//			String name = currentFichaList[ccnt].fdID;
//			listaFd.append(name + " " + currentFichaList[ccnt].folha_FolID,
//					null);
//		}
//		Display.getDisplay(this).setCurrent(listaFd);
//	}

	private void showForm(Ficha c) {
		EditFormFd formFd = null;
		formFd.setFicha(c);
//		Display.getDisplay(this).setCurrent(formFd);
	}

	public void commandAction(Command cmd, Displayable d) {
		if (cmd == exitCmd) {
//			destroyApp(true);
//			notifyDestroyed();
		} else if ((d == listaFd) && (cmd == addCmd)) {
			formFd.setFicha(new Ficha());
			UIController.getInstance().formFd();
//			Display.getDisplay(this).setCurrent(formFd);
		} else if ((d == formFd) && (cmd == saveCmd)) {
			Ficha c = formFd.getFicha();
			c.store();
//			refreshList();
		} else if ((d == listaFd) && (cmd == selectCmd)) {
			showForm(currentFichaList[listaFd.getSelectedIndex()]);
		} else if ((d == formFd) && (cmd == deleteCmd)) {
			formFd.getFicha().delete();
//			refreshList();
		} else if ((d == formFd) && (cmd == deleteCmd)) {
//			refreshList();
		} else if ((d == listaFd) && (cmd == searchCmd)) {
			UIController.getInstance().searchFormFd();
//			Display.getDisplay(this).setCurrent(searchFormFd);
		} else if ((d == searchFormFd) && (cmd == searchCmd)) {
			nameFilter.criteria = searchFormFd.getCriteria();
//			refreshList();
		} else if ((d == formFd) && (cmd == cancelCmd)) {
//			refreshList();
		}
	}
}
