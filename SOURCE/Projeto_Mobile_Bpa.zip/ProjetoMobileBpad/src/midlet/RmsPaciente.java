package midlet;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;
import javax.microedition.midlet.MIDlet;

import record.NameComparatorPc;
import record.NameFilterPc;
import form.EditFormPc;
import form.Paciente;
import form.SearchFormPc;

public class RmsPaciente extends MIDlet implements CommandListener {
	Command addCmd = new Command("Novo Paciente", Command.SCREEN, 1);
	Command selectCmd = new Command("Visualizar", Command.ITEM, 1);
	Command exitCmd = new Command("Sair", Command.EXIT, 1);

	Command saveCmd = new Command("Salvar", Command.SCREEN, 1);
	Command deleteCmd = new Command("Remover", Command.SCREEN, 1);
	Command cancelCmd = new Command("Cancelar", Command.SCREEN, 1);

	Command searchCmd = new Command("Buscar", Command.SCREEN, 1);

	List listaPc = new List("Pacientes", List.IMPLICIT);
	EditFormPc formPc = new EditFormPc();
	SearchFormPc searchFormPc = new SearchFormPc();

	NameComparatorPc orderby = new NameComparatorPc();
	NameFilterPc nameFilter = new NameFilterPc(orderby);

	private Paciente[] currentPacienteList;

	public RmsPaciente() {
		formPc.addCommand(saveCmd);
		formPc.addCommand(cancelCmd);
		formPc.addCommand(deleteCmd);
		formPc.setCommandListener(this);

		searchFormPc.addCommand(searchCmd);
		searchFormPc.setCommandListener(this);

		listaPc.addCommand(searchCmd);
		listaPc.addCommand(addCmd);
		listaPc.addCommand(exitCmd);
		listaPc.setSelectCommand(selectCmd);
		listaPc.setCommandListener(this);

	}

	public void startApp() {
		refreshList();
	}

	public void pauseApp() {
	}

	public void destroyApp(boolean unc) {
	}

	private void refreshList() {
		listaPc.deleteAll();
		currentPacienteList = Paciente.listaPc(orderby, nameFilter);
		for (int ccnt = 0; ccnt < currentPacienteList.length; ccnt++) {
			String name = currentPacienteList[ccnt].pcCns;
			listaPc.append(name + " " + currentPacienteList[ccnt].pcNome, null);
		}
		Display.getDisplay(this).setCurrent(listaPc);
	}

	private void showForm(Paciente c) {
		formPc.setPaciente(c);
		Display.getDisplay(this).setCurrent(formPc);
	}

	public void commandAction(Command cmd, Displayable d) {
		if (cmd == exitCmd) {
			destroyApp(true);
			notifyDestroyed();
		} else if ((d == listaPc) && (cmd == addCmd)) {
			formPc.setPaciente(new Paciente());
			Display.getDisplay(this).setCurrent(formPc);
		} else if ((d == formPc) && (cmd == saveCmd)) {
			Paciente c = formPc.getPaciente();
			c.store();
			refreshList();
		} else if ((d == listaPc) && (cmd == selectCmd)) {
			showForm(currentPacienteList[listaPc.getSelectedIndex()]);
		} else if ((d == formPc) && (cmd == deleteCmd)) {
			formPc.getPaciente().delete();
			refreshList();
		} else if ((d == formPc) && (cmd == deleteCmd)) {
			refreshList();
		} else if ((d == listaPc) && (cmd == searchCmd)) {
			Display.getDisplay(this).setCurrent(searchFormPc);
		} else if ((d == searchFormPc) && (cmd == searchCmd)) {
			nameFilter.criteria = searchFormPc.getCriteria();
			refreshList();
		} else if ((d == formPc) && (cmd == cancelCmd)) {
			refreshList();
		}
	}

}
